# PyQt5-Calculator
A simple calculator made using PyQt5 via Qt Designer 
This was made with the help of PyQt5 Qt-designer to develop the GUI interface and can calculate simple expression using parentheses to define precedence, as a normal math expression.
